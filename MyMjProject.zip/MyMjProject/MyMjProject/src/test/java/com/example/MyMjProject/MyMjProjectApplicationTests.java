package com.example.MyMjProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyMjProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
