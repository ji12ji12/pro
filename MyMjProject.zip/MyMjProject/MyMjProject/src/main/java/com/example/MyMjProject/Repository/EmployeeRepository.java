package com.example.MyMjProject.Repository;

import com.example.MyMjProject.Entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, String> {
    @Query("SELECT e FROM Employee e JOIN e.team_id t WHERE t.team_id = :teamId")
    List<Employee> findByTeam_Id(@Param("teamId") String teamId);

    List<Employee> findAll();

}
