package com.example.MyMjProject.Repository;

import com.example.MyMjProject.Entity.login_mj;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface login_mjRepository extends JpaRepository<login_mj, String> {

    @Query(value = "SELECT * FROM login_mj WHERE employeeId = :employeeId", nativeQuery = true)
    login_mj findByEmployeeId(@Param("employeeId") String employeeId);
}