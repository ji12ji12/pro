package com.example.MyMjProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyMjProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyMjProjectApplication.class, args);
	}

}
