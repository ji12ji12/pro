package com.example.MyMjProject.Controller;

import com.example.MyMjProject.Entity.Employee;
import com.example.MyMjProject.Entity.Team;
import com.example.MyMjProject.service.EmployeeService;
import com.example.MyMjProject.service.TeamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Controller
public class TeamController {

    private final TeamService teamService;
    private final EmployeeService employeeService;

    @Autowired
    public TeamController(TeamService teamService, EmployeeService employeeService) {
        this.teamService = teamService;
        this.employeeService = employeeService;
    }

    @RequestMapping("/team")
    public String getTeamMembers(@RequestParam(name = "to") String employeeName,@RequestParam(name = "team_id") String teamId, Model model) {
        // 로깅 추가
        String teamName = null;
        if(teamId.equals("T001")){
            teamName = "국방 시설 통합 정보 체계";
        } else if (teamId.equals("T002")) {
            teamName = "개발/유지보수";
        } else if (teamId.equals("T003")) {
            teamName = "의왕 은행";
        } else if (teamId.equals("T004")) {
            teamName = "의왕 통합 멤버스";
        } else if (teamId.equals("T005")) {
            teamName = "의왕 VAN";
        } else if (teamId.equals("T006")) {
            teamName = "의왕 NH농협생명";
        } else if (teamId.equals("T007")) {
            teamName = "의왕 NH캐피탈/NH저축은행";
        } else if (teamId.equals("T008")) {
            teamName = "안성센터";
        } else if (teamId.equals("T009")) {
            teamName = "여의도 IDC";
        } else if (teamId.equals("T010")) {
            teamName = "영업 관리부";
        }
        System.out.println("Team ID: " + teamId + ", Team Name: " + teamName);
        // teamId를 기반으로 해당 팀의 직원 정보를 가져와 모델에 추가
        List<Employee> teamMembers = employeeService.getEmployeesByTeamId(teamId);

        // 로깅 추가
        System.out.println("Team Members: " + teamMembers);

        model.addAttribute("teamMembers", teamMembers);
        model.addAttribute("teamName", teamName);
        model.addAttribute("employeeName",employeeName);
        return "teamMembers";
    }



    @RequestMapping("/selectTeam")
    public String selectTeam(@RequestParam(name = "to") String employeeName , Model model) {
        // 모든 팀 정보 가져오기
        List<Team> teams = teamService.getAllTeams();

        List<String> filterTeamIds = Arrays.asList("TO10");

        // 필터링된 팀 목록
        List<Team> filteredTeams = teams.stream()
                .filter(team -> filterTeamIds.contains(team.getTeam_id()))
                .collect(Collectors.toList());
        // 모델에 팀 목록 추가
        model.addAttribute("teams", filteredTeams);

        // 모델에 빈 Team 객체 추가
        model.addAttribute("selectedTeam", new Team());
        model.addAttribute("employeeName",employeeName);
        // selectTeam.html로 이동
        return "selectTeam";
    }

    @RequestMapping("/selectTeamTwo")
    public String selectTeamTwo(@RequestParam(name = "to") String employeeName , Model model) {
        // 모든 팀 정보 가져오기
        List<Team> teams = teamService.getAllTeams();

        List<String> filterTeamIds = Arrays.asList("TOO3", "TOO4", "TOO5", "TOO6", "TOO7", "TOO8", "TOO9");

        // 필터링된 팀 목록
        List<Team> filteredTeams = teams.stream()
                .filter(team -> filterTeamIds.contains(team.getTeam_id()))
                .collect(Collectors.toList());
        // 모델에 팀 목록 추가
        model.addAttribute("teams", filteredTeams);

        // 모델에 빈 Team 객체 추가
        model.addAttribute("selectedTeam", new Team());
        model.addAttribute("employeeName",employeeName);
        // selectTeam.html로 이동
        return "selectTeam";
    }

    @RequestMapping("/selectTeamThree")
    public String selectTeamThree(@RequestParam(name = "to") String employeeName , Model model) {
        // 모든 팀 정보 가져오기
        List<Team> teams = teamService.getAllTeams();

        List<String> filterTeamIds = Arrays.asList("TOO1", "TOO2");

        // 필터링된 팀 목록
        List<Team> filteredTeams = teams.stream()
                .filter(team -> filterTeamIds.contains(team.getTeam_id()))
                .collect(Collectors.toList());
        // 모델에 팀 목록 추가
        model.addAttribute("teams", filteredTeams);

        // 모델에 빈 Team 객체 추가
        model.addAttribute("selectedTeam", new Team());
        model.addAttribute("employeeName",employeeName);
        // selectTeam.html로 이동
        return "selectTeam";
    }

    @GetMapping("/allEmployees")
    public String getAllEmployees(@RequestParam(name = "to") String employeeName , Model model) {
        List<Employee> allEmployees = employeeService.getAllEmployees();

        model.addAttribute("teamMembers", allEmployees);
        model.addAttribute("teamName", "전체 직원 정보");
        model.addAttribute("employeeName",employeeName);

        return "teamMembersAll";
    }
}