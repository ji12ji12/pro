package com.example.MyMjProject.service;

import com.example.MyMjProject.Entity.login_mj;
import com.example.MyMjProject.Repository.login_mjRepository;
import org.springframework.stereotype.Service;

@Service
public class login_mjService {
    private final login_mjRepository login_MJRepository;

    public login_mjService(login_mjRepository login_MJRepository) {
        this.login_MJRepository = login_MJRepository;
    }

    // 사용자 아이디로 사용자 정보를 조회하는 메서드
    public login_mj getUserBylogin_mjId(String employeeId) {
        System.out.println("Retrieved user from database: " + employeeId);
        return login_MJRepository.findByEmployeeId(employeeId);
    }

    // 사용자 비밀번호가 유효한지 검사하는 메서드
    public boolean isLogin_mjValId(String employeeId, String employeePw) {
        login_mj login = getUserBylogin_mjId(employeeId);
        if (login != null) {
            System.out.println("Retrieved user details: " + login.toString());
        } else {
            System.out.println("No user found for employeeId: " + employeeId);
        }

        return login != null && login.getEmployeePw() != null && login.getEmployeePw().equals(employeePw);
    }
}

