package com.example.MyMjProject.Entity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Transient;
import lombok.Getter;

@Entity
public class login_mj {
    @Getter
    @Id
    @Column(name = "employeeId")
    private String employeeId;
    @Getter
    @Column(name = "employeePw")
    private String employeePw;

    public login_mj() {
        this.employeeId = null;
        this.employeePw = null;
    }
    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public void setEmployeePw(String employeePw) {
        this.employeePw = employeePw;
    }
    @Override
    public String toString() {
        return "login_mj{" +
                "employeeId='" + employeeId + '\'' +
                ", employeePw='" + employeePw + '\'' +
                '}';
    }
}
