package com.example.MyMjProject.Controller;

import com.example.MyMjProject.Entity.login_mj;
import com.example.MyMjProject.service.EmployeeService;
import com.example.MyMjProject.service.login_mjService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequiredArgsConstructor
public class HomeController {
    private final login_mjService login_MJService;
    private final EmployeeService employeeService;
    @RequestMapping("/")
    public String index(){
        return "index";
    }
    @PostMapping("/login")
    public String processLogin(@RequestParam String employeeId, @RequestParam String employeePw, Model model) {
        // 사용자 정보가 유효한지 검사
        if (!login_MJService.isLogin_mjValId(employeeId, employeePw)) {
            model.addAttribute("loginError", true);
            return "loginError";  // 로그인 실패 시 다시 로그인 페이지로 이동
        }
        String employeeName = employeeService.getEmployeeNameById(employeeId);
        // 로그인 성공 시 받아온 정보를 모델에 추가하여 결과 페이지로 이동
        model.addAttribute("employeeName", employeeName);
        return "chart";  // 로그인 성공 시 결과 페이지로 이동
    }
    @RequestMapping("/employee")
    public String employee(@RequestParam(name = "to") String employeeName , Model model){
        model.addAttribute("employeeName",employeeName);
        return "employee";
    }
    @RequestMapping("/chart")
    public String chart(){return "chart";}
}


