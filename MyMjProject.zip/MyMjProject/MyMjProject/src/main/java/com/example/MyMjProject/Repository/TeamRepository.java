package com.example.MyMjProject.Repository;

import com.example.MyMjProject.Entity.Team;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TeamRepository extends JpaRepository<Team, String> {
    // 팀과 관련된 추가적인 메서드가 필요하다면 여기에 추가할 수 있습니다.
}
