package com.example.MyMjProject.Entity;

import jakarta.persistence.*;

@Entity
@Table(name="team")
public class Team {
    @Id
    @Column(name="team_id")
    private String team_id;
    @Column(name="depart_id")
    private String depart_id;
    @Column(name="team_name")
    private String team_name;

    public String getTeam_id() {
        return team_id;
    }

    public void setTeam_id(String team_id) {
        this.team_id = team_id;
    }

    public String getDepart_id() {
        return depart_id;
    }

    public void setDepart_id(String depart_id) {
        this.depart_id = depart_id;
    }

    public String getTeam_name() {
        return team_name;
    }

    public void setTeam_name(String team_name) {
        this.team_name = team_name;
    }
}
