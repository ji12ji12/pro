package com.example.MyMjProject.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class borderController {
    @RequestMapping("/border")
    public String border(@RequestParam(name = "to") String employeeName, Model model){
        model.addAttribute("employeeName",employeeName);
        return "border";
    }
    @RequestMapping("/write")
    public String write(@RequestParam(name = "to") String employeeName, Model model){
        model.addAttribute("employeeName",employeeName);
        return "write";
    }
}
