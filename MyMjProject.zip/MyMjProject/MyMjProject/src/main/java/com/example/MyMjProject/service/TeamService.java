package com.example.MyMjProject.service;

import com.example.MyMjProject.Entity.Team;
import com.example.MyMjProject.Repository.TeamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TeamService {

    private final TeamRepository teamRepository;

    @Autowired
    public TeamService(TeamRepository teamRepository) {
        this.teamRepository = teamRepository;
    }

    // 모든 팀 정보 가져오기
    public List<Team> getAllTeams() {
        return teamRepository.findAll();
    }
    public Team getTeamById(String teamId) {
        return teamRepository.findById(teamId).orElse(null);
    }
}
