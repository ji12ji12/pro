package com.example.MyMjProject.Entity;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name="employee")
public class Employee {
    @Id
    @Column(name = "employeeId")
    private String employeeId;
    @Column(name = "belong")
    private String belong;
    @Column(name = "e_name")
    private String e_name;
    @Column(name = "ranks")
    private String ranks;
    @Column(name = "gender")
    private String gender;
    @Column(name = "join_date")
    private LocalDate join_date;
    @Column(name = "respons")
    private String respons;
    @Column(name = "birth_date")
    private LocalDate birth_date;
    @Column(name = "mail")
    private String mail;
    @ManyToOne
    @JoinColumn(name = "team_id")
    private Team team_id;

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getBelong() {
        return belong;
    }

    public void setBelong(String belong) {
        this.belong = belong;
    }

    public String getE_name() {
        return e_name;
    }

    public void setE_name(String e_name) {
        this.e_name = e_name;
    }

    public String getRanks() {
        return ranks;
    }

    public void setRanks(String ranks) {
        this.ranks = ranks;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public LocalDate getJoin_date() {
        return join_date;
    }

    public void setJoin_date(LocalDate join_date) {
        this.join_date = join_date;
    }

    public String getRespons() {
        return respons;
    }

    public void setRespons(String respons) {
        this.respons = respons;
    }

    public LocalDate getBirth_date() {
        return birth_date;
    }

    public void setBirth_date(LocalDate birth_date) {
        this.birth_date = birth_date;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public Team getTeam_id() {
        return team_id;
    }

    public void setTeam_id(Team team_id) {
        this.team_id = team_id;
    }
}
